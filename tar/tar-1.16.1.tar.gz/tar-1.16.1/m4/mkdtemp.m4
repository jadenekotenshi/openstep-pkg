# mkdtemp.m4 serial 4
dnl Copyright (C) 2001-2003, 2006 Free Software Foundation, Inc.
dnl This file is free software; the Free Software Foundation
dnl gives unlimited permission to copy and/or distribute it,
dnl with or without modifications, as long as this notice is preserved.

AC_DEFUN([gt_FUNC_MKDTEMP],
[
  AC_REPLACE_FUNCS(mkdtemp)
  if test $ac_cv_func_mkdtemp = no; then
    gl_PREREQ_MKDTEMP
  fi
])

# Prerequisites of lib/mkdtemp.c
AC_DEFUN([gl_PREREQ_MKDTEMP],
[:
])
