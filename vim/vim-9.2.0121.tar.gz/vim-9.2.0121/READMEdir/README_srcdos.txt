README_srcdos.txt for version 9.2 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-Windows.
These files are in the runtime archive (vim92rt.zip).


The DOS source archive contains the files needed to compile Vim on MS-Windows.
It is packed for MS-Windows systems, with CR-LF.

See "src/INSTALLpc.txt" for instructions on how to compile Vim on the PC.
