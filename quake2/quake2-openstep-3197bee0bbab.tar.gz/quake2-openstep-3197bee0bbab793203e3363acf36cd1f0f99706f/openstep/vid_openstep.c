/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// OPENSTEP software-renderer glue, derived from null/vid_null.c
// this assumes that one of the refs is statically linked to the executable

#include "../client/client.h"
#include "../client/keys.h"

viddef_t	viddef;				// global video state

refexport_t	re;
static cvar_t *vid_mode_alias;
static cvar_t *sw_mode_cvar;

refexport_t GetRefAPI (refimport_t rimp);

/*
==========================================================================

DIRECT LINK GLUE

==========================================================================
*/

#define	MAXPRINTMSG	4096
void VID_Printf (int print_level, char *fmt, ...)
{
        va_list		argptr;
        char		msg[MAXPRINTMSG];

        va_start (argptr,fmt);
        vsprintf (msg,fmt,argptr);
        va_end (argptr);

        if (print_level == PRINT_ALL)
                Com_Printf ("%s", msg);
        else
                Com_DPrintf ("%s", msg);
}

void VID_Error (int err_level, char *fmt, ...)
{
        va_list		argptr;
        char		msg[MAXPRINTMSG];

        va_start (argptr,fmt);
        vsprintf (msg,fmt,argptr);
        va_end (argptr);

		Com_Error (err_level, "%s", msg);
}

void VID_NewWindow (int width, int height)
{
        viddef.width = width;
        viddef.height = height;
        /* A paused view still contains the previous framebuffer dimensions. */
        cl.force_refdef = true;
}

/*
** VID_GetModeInfo
*/
typedef struct vidmode_s
{
    const char *description;
    int         width, height;
    int         mode;
} vidmode_t;

vidmode_t vid_modes[] =
{
    { "Mode 0: 320x240",   320, 240,   0 },
    { "Mode 1: 400x300",   400, 300,   1 },
    { "Mode 2: 512x384",   512, 384,   2 },
    { "Mode 3: 640x480",   640, 480,   3 },
    { "Mode 4: 800x600",   800, 600,   4 },
    { "Mode 5: 960x720",   960, 720,   5 },
    { "Mode 6: 1024x768",  1024, 768,  6 },
    { "Mode 7: 1152x864",  1152, 864,  7 },
    { "Mode 8: 1280x960",  1280, 960, 8 },
    { "Mode 9: 1600x1200", 1600, 1200, 9 },
	{ "Mode 10: 2048x1536", 2048, 1536, 10 }
};
#define VID_NUM_MODES ( sizeof( vid_modes ) / sizeof( vid_modes[0] ) )

qboolean VID_GetModeInfo( int *width, int *height, int mode )
{
    if ( mode < 0 || mode >= VID_NUM_MODES )
        return false;

    *width  = vid_modes[mode].width;
    *height = vid_modes[mode].height;

    return true;
}


void	VID_Init (void)
{
    refimport_t	ri;

    /* An explicitly supplied vid_mode takes precedence at startup. */
    vid_mode_alias = Cvar_Get ("vid_mode", "", CVAR_ARCHIVE);
    sw_mode_cvar = Cvar_Get ("sw_mode", "0", CVAR_ARCHIVE);
    if (vid_mode_alias->string[0])
        Cvar_Set ("sw_mode", vid_mode_alias->string);
    Cvar_Set ("vid_mode", sw_mode_cvar->string);
    vid_mode_alias->modified = false;

    viddef.width = 320;
    viddef.height = 240;

    ri.Cmd_AddCommand = Cmd_AddCommand;
    ri.Cmd_RemoveCommand = Cmd_RemoveCommand;
    ri.Cmd_Argc = Cmd_Argc;
    ri.Cmd_Argv = Cmd_Argv;
    ri.Cmd_ExecuteText = Cbuf_ExecuteText;
    ri.Con_Printf = VID_Printf;
    ri.Sys_Error = VID_Error;
    ri.FS_LoadFile = FS_LoadFile;
    ri.FS_FreeFile = FS_FreeFile;
    ri.FS_Gamedir = FS_Gamedir;
	ri.Vid_NewWindow = VID_NewWindow;
    ri.Cvar_Get = Cvar_Get;
    ri.Cvar_Set = Cvar_Set;
    ri.Cvar_SetValue = Cvar_SetValue;
    ri.Vid_GetModeInfo = VID_GetModeInfo;

    re = GetRefAPI(ri);

    if (re.api_version != API_VERSION)
        Com_Error (ERR_FATAL, "Re has incompatible api_version");

        // call the init function
    if (re.Init (NULL, NULL) == -1)
		Com_Error (ERR_FATAL, "Couldn't start refresh");
}

void	VID_Shutdown (void)
{
    if (re.Shutdown)
	    re.Shutdown ();
}

void VID_CheckChanges (void)
{
    if (vid_mode_alias->modified)
        Cvar_Set ("sw_mode", vid_mode_alias->string);
    else if (strcmp(vid_mode_alias->string, sw_mode_cvar->string))
        Cvar_Set ("vid_mode", sw_mode_cvar->string);
    vid_mode_alias->modified = false;
}

void	VID_MenuInit (void)
{
}

void	VID_MenuDraw (void)
{
    extern void M_Print(int x, int y, char *text);
    M_Print(112, 24, "Video");
    M_Print(24, 56, "Use the console to set video:");
    M_Print(32, 80, "vid_mode 0: 320 x 240");
    M_Print(32, 96, "vid_mode 3: 640 x 480");
    M_Print(32, 112, "vid_mode 6: 1024 x 768");
    M_Print(32, 128, "vid_mode 7: 1152 x 864");
    M_Print(32, 144, "vid_mode 8: 1280 x 960");
    M_Print(32, 160, "vid_mode 9: 1600 x 1200");
    M_Print(32, 184, "vid_fullscreen 1: fullscreen");
    M_Print(32, 200, "vid_fullscreen 0: windowed");
    M_Print(32, 216, "Option-Enter toggles fullscreen");
    M_Print(32, 232, "Press Escape to return");
}

const char *VID_MenuKey( int k)
{
	extern void M_PopMenu(void);
	if (k == K_ESCAPE || k == K_ENTER)
		M_PopMenu();
	return NULL;
}
